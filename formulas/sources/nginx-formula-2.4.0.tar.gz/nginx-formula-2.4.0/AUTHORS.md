# Authors

This list is sorted by the number of commits per contributor in _descending_ order.

Avatar|Contributor|Contributions
:-:|---|:-:
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/10231489?v=4' width='36' height='36' alt='@myii'>|[@myii](https://github.com/myii)|58
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/1800660?v=4' width='36' height='36' alt='@aboe76'>|[@aboe76](https://github.com/aboe76)|46
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/1396878?v=4' width='36' height='36' alt='@gravyboat'>|[@gravyboat](https://github.com/gravyboat)|27
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/3374962?v=4' width='36' height='36' alt='@nmadhok'>|[@nmadhok](https://github.com/nmadhok)|24
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/13322818?v=4' width='36' height='36' alt='@noelmcloughlin'>|[@noelmcloughlin](https://github.com/noelmcloughlin)|18
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/91293?v=4' width='36' height='36' alt='@whiteinge'>|[@whiteinge](https://github.com/whiteinge)|17
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/4956475?v=4' width='36' height='36' alt='@ross-p'>|[@ross-p](https://github.com/ross-p)|13
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/52996?v=4' width='36' height='36' alt='@daks'>|[@daks](https://github.com/daks)|11
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/287147?v=4' width='36' height='36' alt='@techhat'>|[@techhat](https://github.com/techhat)|10
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/242396?v=4' width='36' height='36' alt='@javierbertoli'>|[@javierbertoli](https://github.com/javierbertoli)|9
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/445200?v=4' width='36' height='36' alt='@arthurlogilab'>|[@arthurlogilab](https://github.com/arthurlogilab)|8
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/1184479?v=4' width='36' height='36' alt='@cheuschober'>|[@cheuschober](https://github.com/cheuschober)|8
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/378158?v=4' width='36' height='36' alt='@dseira'>|[@dseira](https://github.com/dseira)|8
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/941928?v=4' width='36' height='36' alt='@amontalban'>|[@amontalban](https://github.com/amontalban)|7
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/528061?v=4' width='36' height='36' alt='@puneetk'>|[@puneetk](https://github.com/puneetk)|7
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/6354880?v=4' width='36' height='36' alt='@TaiSHiNet'>|[@TaiSHiNet](https://github.com/TaiSHiNet)|6
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/745513?v=4' width='36' height='36' alt='@EvaSDK'>|[@EvaSDK](https://github.com/EvaSDK)|6
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/3280630?v=4' width='36' height='36' alt='@cackovic'>|[@cackovic](https://github.com/cackovic)|5
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/529?v=4' width='36' height='36' alt='@auser'>|[@auser](https://github.com/auser)|5
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/3768412?v=4' width='36' height='36' alt='@stp-ip'>|[@stp-ip](https://github.com/stp-ip)|5
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/1060507?v=4' width='36' height='36' alt='@ahmadsherif'>|[@ahmadsherif](https://github.com/ahmadsherif)|4
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/3433835?v=4' width='36' height='36' alt='@n-rodriguez'>|[@n-rodriguez](https://github.com/n-rodriguez)|4
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/37182?v=4' width='36' height='36' alt='@teepark'>|[@teepark](https://github.com/teepark)|4
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/4754654?v=4' width='36' height='36' alt='@alinefr'>|[@alinefr](https://github.com/alinefr)|3
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/5412167?v=4' width='36' height='36' alt='@devaos'>|[@devaos](https://github.com/devaos)|3
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/637990?v=4' width='36' height='36' alt='@bmwiedemann'>|[@bmwiedemann](https://github.com/bmwiedemann)|3
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/328598?v=4' width='36' height='36' alt='@terminalmage'>|[@terminalmage](https://github.com/terminalmage)|3
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/94157?v=4' width='36' height='36' alt='@imran1008'>|[@imran1008](https://github.com/imran1008)|3
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/783794?v=4' width='36' height='36' alt='@morsik'>|[@morsik](https://github.com/morsik)|3
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/7060082?v=4' width='36' height='36' alt='@msciciel'>|[@msciciel](https://github.com/msciciel)|3
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/8029478?v=4' width='36' height='36' alt='@rfairburn'>|[@rfairburn](https://github.com/rfairburn)|3
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/50891?v=4' width='36' height='36' alt='@westurner'>|[@westurner](https://github.com/westurner)|3
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/813115?v=4' width='36' height='36' alt='@chris-sanders'>|[@chris-sanders](https://github.com/chris-sanders)|2
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/306240?v=4' width='36' height='36' alt='@UtahDave'>|[@UtahDave](https://github.com/UtahDave)|2
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/51596?v=4' width='36' height='36' alt='@ghtyrant'>|[@ghtyrant](https://github.com/ghtyrant)|2
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/56635?v=4' width='36' height='36' alt='@pprkut'>|[@pprkut](https://github.com/pprkut)|2
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/85002?v=4' width='36' height='36' alt='@jstrunk'>|[@jstrunk](https://github.com/jstrunk)|2
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/5306980?v=4' width='36' height='36' alt='@johnkeates'>|[@johnkeates](https://github.com/johnkeates)|2
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/2200073?v=4' width='36' height='36' alt='@kmshultz'>|[@kmshultz](https://github.com/kmshultz)|2
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/11417?v=4' width='36' height='36' alt='@malept'>|[@malept](https://github.com/malept)|2
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/3279679?v=4' width='36' height='36' alt='@meganlkm'>|[@meganlkm](https://github.com/meganlkm)|2
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/84885?v=4' width='36' height='36' alt='@garrettw'>|[@garrettw](https://github.com/garrettw)|2
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/101513?v=4' width='36' height='36' alt='@ErisDS'>|[@ErisDS](https://github.com/ErisDS)|2
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/879922?v=4' width='36' height='36' alt='@myoung34'>|[@myoung34](https://github.com/myoung34)|2
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/1922124?v=4' width='36' height='36' alt='@bebosudo'>|[@bebosudo](https://github.com/bebosudo)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/8395913?v=4' width='36' height='36' alt='@aanriot'>|[@aanriot](https://github.com/aanriot)|1
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/7460036?v=4' width='36' height='36' alt='@andrew-vant'>|[@andrew-vant](https://github.com/andrew-vant)|1
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/2106845?v=4' width='36' height='36' alt='@bemosior'>|[@bemosior](https://github.com/bemosior)|1
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/458548?v=4' width='36' height='36' alt='@SuperTux88'>|[@SuperTux88](https://github.com/SuperTux88)|1
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/1079875?v=4' width='36' height='36' alt='@bogdanr'>|[@bogdanr](https://github.com/bogdanr)|1
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/1435085?v=4' width='36' height='36' alt='@blbradley'>|[@blbradley](https://github.com/blbradley)|1
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/2459661?v=4' width='36' height='36' alt='@CorwinTanner'>|[@CorwinTanner](https://github.com/CorwinTanner)|1
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/1686586?v=4' width='36' height='36' alt='@fayetted'>|[@fayetted](https://github.com/fayetted)|1
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/72727?v=4' width='36' height='36' alt='@czarneckid'>|[@czarneckid](https://github.com/czarneckid)|1
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/983?v=4' width='36' height='36' alt='@statik'>|[@statik](https://github.com/statik)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/48329?v=4' width='36' height='36' alt='@ekristen'>|[@ekristen](https://github.com/ekristen)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/75496?v=4' width='36' height='36' alt='@jeduardo'>|[@jeduardo](https://github.com/jeduardo)|1
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/668449?v=4' width='36' height='36' alt='@stromnet'>|[@stromnet](https://github.com/stromnet)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/744549?v=4' width='36' height='36' alt='@bsdlp'>|[@bsdlp](https://github.com/bsdlp)|1
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/5395035?v=4' width='36' height='36' alt='@MEschenbacher'>|[@MEschenbacher](https://github.com/MEschenbacher)|1
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/225115?v=4' width='36' height='36' alt='@renich'>|[@renich](https://github.com/renich)|1
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/62993?v=4' width='36' height='36' alt='@outime'>|[@outime](https://github.com/outime)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/991850?v=4' width='36' height='36' alt='@scub'>|[@scub](https://github.com/scub)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/507599?v=4' width='36' height='36' alt='@thatch45'>|[@thatch45](https://github.com/thatch45)|1
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/479088?v=4' width='36' height='36' alt='@blarghmatey'>|[@blarghmatey](https://github.com/blarghmatey)|1
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/117961?v=4' width='36' height='36' alt='@babilen5'>|[@babilen5](https://github.com/babilen5)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/228723?v=4' width='36' height='36' alt='@abednarik'>|[@abednarik](https://github.com/abednarik)|1
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/19428823?v=4' width='36' height='36' alt='@francesco-a'>|[@francesco-a](https://github.com/francesco-a)|1
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/1068764?v=4' width='36' height='36' alt='@oboyle'>|[@oboyle](https://github.com/oboyle)|1
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/542613?v=4' width='36' height='36' alt='@bersace'>|[@bersace](https://github.com/bersace)|1

---

Auto-generated by a [forked version](https://github.com/myii/maintainer) of [gaocegege/maintainer](https://github.com/gaocegege/maintainer) on 2020-03-31.
