# Authors

This list is sorted by the number of commits per contributor in _descending_ order.

Avatar|Contributor|Contributions
:-:|---|:-:
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/10231489?v=4' width='36' height='36' alt='@myii'>|[@myii](https://github.com/myii)|57
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/242396?v=4' width='36' height='36' alt='@javierbertoli'>|[@javierbertoli](https://github.com/javierbertoli)|33
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/1396878?v=4' width='36' height='36' alt='@gravyboat'>|[@gravyboat](https://github.com/gravyboat)|21
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/18069703?v=4' width='36' height='36' alt='@crux-capacitor'>|[@crux-capacitor](https://github.com/crux-capacitor)|14
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/3374962?v=4' width='36' height='36' alt='@nmadhok'>|[@nmadhok](https://github.com/nmadhok)|11
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/1920805?v=4' width='36' height='36' alt='@alxwr'>|[@alxwr](https://github.com/alxwr)|11
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/2995329?v=4' width='36' height='36' alt='@t0fik'>|[@t0fik](https://github.com/t0fik)|10
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/1800660?v=4' width='36' height='36' alt='@aboe76'>|[@aboe76](https://github.com/aboe76)|10
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/8395913?v=4' width='36' height='36' alt='@aanriot'>|[@aanriot](https://github.com/aanriot)|9
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/5682028?v=4' width='36' height='36' alt='@nadvornik'>|[@nadvornik](https://github.com/nadvornik)|9
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/2094680?v=4' width='36' height='36' alt='@daschatten'>|[@daschatten](https://github.com/daschatten)|9
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/4323424?v=4' width='36' height='36' alt='@joe-bowman'>|[@joe-bowman](https://github.com/joe-bowman)|7
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/637990?v=4' width='36' height='36' alt='@bmwiedemann'>|[@bmwiedemann](https://github.com/bmwiedemann)|6
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/52996?v=4' width='36' height='36' alt='@daks'>|[@daks](https://github.com/daks)|6
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/6322354?v=4' width='36' height='36' alt='@ppieprzycki'>|[@ppieprzycki](https://github.com/ppieprzycki)|5
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/507599?v=4' width='36' height='36' alt='@thatch45'>|[@thatch45](https://github.com/thatch45)|5
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/528061?v=4' width='36' height='36' alt='@puneetk'>|[@puneetk](https://github.com/puneetk)|5
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/287147?v=4' width='36' height='36' alt='@techhat'>|[@techhat](https://github.com/techhat)|4
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/10901150?v=4' width='36' height='36' alt='@ryanwalder'>|[@ryanwalder](https://github.com/ryanwalder)|4
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/6639666?v=4' width='36' height='36' alt='@ukretschmer'>|[@ukretschmer](https://github.com/ukretschmer)|4
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/117961?v=4' width='36' height='36' alt='@babilen5'>|[@babilen5](https://github.com/babilen5)|4
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/18299?v=4' width='36' height='36' alt='@davidkarlsen'>|[@davidkarlsen](https://github.com/davidkarlsen)|4
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/811611?v=4' width='36' height='36' alt='@cosu'>|[@cosu](https://github.com/cosu)|3
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/718525?v=4' width='36' height='36' alt='@garethgreenaway'>|[@garethgreenaway](https://github.com/garethgreenaway)|3
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/4156131?v=4' width='36' height='36' alt='@skylerberg'>|[@skylerberg](https://github.com/skylerberg)|3
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/1806188?v=4' width='36' height='36' alt='@tedski'>|[@tedski](https://github.com/tedski)|3
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/6215293?v=4' width='36' height='36' alt='@0xf10e'>|[@0xf10e](https://github.com/0xf10e)|2
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/5789536?v=4' width='36' height='36' alt='@ogabrielsantos'>|[@ogabrielsantos](https://github.com/ogabrielsantos)|2
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/3768412?v=4' width='36' height='36' alt='@stp-ip'>|[@stp-ip](https://github.com/stp-ip)|2
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/91293?v=4' width='36' height='36' alt='@whiteinge'>|[@whiteinge](https://github.com/whiteinge)|2
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/1622925?v=4' width='36' height='36' alt='@alexeiswirth'>|[@alexeiswirth](https://github.com/alexeiswirth)|2
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/3122114?v=4' width='36' height='36' alt='@kiwiz'>|[@kiwiz](https://github.com/kiwiz)|2
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/976976?v=4' width='36' height='36' alt='@Aloz1'>|[@Aloz1](https://github.com/Aloz1)|1
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/1079875?v=4' width='36' height='36' alt='@bogdanr'>|[@bogdanr](https://github.com/bogdanr)|1
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/5575236?v=4' width='36' height='36' alt='@BrianSidebotham'>|[@BrianSidebotham](https://github.com/BrianSidebotham)|1
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/776662?v=4' width='36' height='36' alt='@carlosperello'>|[@carlosperello](https://github.com/carlosperello)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/306240?v=4' width='36' height='36' alt='@UtahDave'>|[@UtahDave](https://github.com/UtahDave)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/94157?v=4' width='36' height='36' alt='@imran1008'>|[@imran1008](https://github.com/imran1008)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/7613500?v=4' width='36' height='36' alt='@levlozhkin'>|[@levlozhkin](https://github.com/levlozhkin)|1
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/6086064?v=4' width='36' height='36' alt='@mgomersbach'>|[@mgomersbach](https://github.com/mgomersbach)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/7139195?v=4' width='36' height='36' alt='@xenophonf'>|[@xenophonf](https://github.com/xenophonf)|1
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/2004149?v=4' width='36' height='36' alt='@barroco'>|[@barroco](https://github.com/barroco)|1
<img class='float-left rounded-1' src='https://avatars2.githubusercontent.com/u/2321403?v=4' width='36' height='36' alt='@nickbooties'>|[@nickbooties](https://github.com/nickbooties)|1
<img class='float-left rounded-1' src='https://avatars1.githubusercontent.com/u/949989?v=4' width='36' height='36' alt='@attiasr'>|[@attiasr](https://github.com/attiasr)|1
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/434444?v=4' width='36' height='36' alt='@tiefpunkt'>|[@tiefpunkt](https://github.com/tiefpunkt)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/13481669?v=4' width='36' height='36' alt='@vmagistro'>|[@vmagistro](https://github.com/vmagistro)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/753483?v=4' width='36' height='36' alt='@AdrienR'>|[@AdrienR](https://github.com/AdrienR)|1
<img class='float-left rounded-1' src='https://avatars0.githubusercontent.com/u/10585477?v=4' width='36' height='36' alt='@blacksmith77'>|[@blacksmith77](https://github.com/blacksmith77)|1
<img class='float-left rounded-1' src='https://avatars3.githubusercontent.com/u/2061751?v=4' width='36' height='36' alt='@matthew-parlette'>|[@matthew-parlette](https://github.com/matthew-parlette)|1

---

Auto-generated by a [forked version](https://github.com/myii/maintainer) of [gaocegege/maintainer](https://github.com/gaocegege/maintainer) on 2020-03-23.
